﻿namespace 졸업작품
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.main_panel = new System.Windows.Forms.TableLayoutPanel();
            this.menutab = new System.Windows.Forms.TabControl();
            this.currypage = new System.Windows.Forms.TabPage();
            this.tab_Panel1 = new System.Windows.Forms.TableLayoutPanel();
            this.mncrry_btn = new System.Windows.Forms.Button();
            this.hbckcrry_btn = new System.Windows.Forms.Button();
            this.sfcrry_btn = new System.Windows.Forms.Button();
            this.frkcrry_btn = new System.Windows.Forms.Button();
            this.bfcrry_btn = new System.Windows.Forms.Button();
            this.shrcrry_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.mncrry_lbl = new System.Windows.Forms.Label();
            this.mncrryprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.fkcrryprc_lbl = new System.Windows.Forms.Label();
            this.frkcrry_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.bfcrryprc_lbl = new System.Windows.Forms.Label();
            this.bfcrry_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.shrcrryprc_lbl = new System.Windows.Forms.Label();
            this.shrcrry_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.hbckcrryprc_lbl = new System.Windows.Forms.Label();
            this.hbckcrry_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.sfcrryprc_lbl = new System.Windows.Forms.Label();
            this.sfcrry_lbl = new System.Windows.Forms.Label();
            this.udonpage = new System.Windows.Forms.TabPage();
            this.tab_Panel2 = new System.Windows.Forms.TableLayoutPanel();
            this.bfudon_btn = new System.Windows.Forms.Button();
            this.mshudon_btn = new System.Windows.Forms.Button();
            this.mnudon_btn = new System.Windows.Forms.Button();
            this.shrudon_btn = new System.Windows.Forms.Button();
            this.sfudon_btn = new System.Windows.Forms.Button();
            this.hbckudon_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.mnudon_lbl = new System.Windows.Forms.Label();
            this.mnudonprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.mshudonprc_lbl = new System.Windows.Forms.Label();
            this.mshudon_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.bfudonprc_lbl = new System.Windows.Forms.Label();
            this.bfudon_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.hbckudonprc_lbl = new System.Windows.Forms.Label();
            this.hbckudon_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.sfudonprc_lbl = new System.Windows.Forms.Label();
            this.sfudon_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.shrudonprc_lbl = new System.Windows.Forms.Label();
            this.shrudon_lbl = new System.Windows.Forms.Label();
            this.pastapage = new System.Windows.Forms.TabPage();
            this.tab_Panel3 = new System.Windows.Forms.TableLayoutPanel();
            this.hbpst_btn = new System.Windows.Forms.Button();
            this.mshpst_btn = new System.Windows.Forms.Button();
            this.mnpst_btn = new System.Windows.Forms.Button();
            this.hbckpst_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.mnpst_lbl = new System.Windows.Forms.Label();
            this.mnpstprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.mshpst_lbl = new System.Windows.Forms.Label();
            this.mshpstprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.hbpst_lbl = new System.Windows.Forms.Label();
            this.hbpstprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.hbckpst_lbl = new System.Windows.Forms.Label();
            this.hbckpstprc_lbl = new System.Windows.Forms.Label();
            this.setpage = new System.Windows.Forms.TabPage();
            this.tab_Panel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.sfset_lbl = new System.Windows.Forms.Label();
            this.sfsetprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.twosetb_lbl = new System.Windows.Forms.Label();
            this.twosetbprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.fkset_lbl = new System.Windows.Forms.Label();
            this.fksetprc_lbl = new System.Windows.Forms.Label();
            this.fkset_btn = new System.Windows.Forms.Button();
            this.ckset_btn = new System.Windows.Forms.Button();
            this.bfset_btn = new System.Windows.Forms.Button();
            this.sfset_btn = new System.Windows.Forms.Button();
            this.twoseta_btn = new System.Windows.Forms.Button();
            this.twosetb_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.bfset_lbl = new System.Windows.Forms.Label();
            this.bfsetprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.ckset_lbl = new System.Windows.Forms.Label();
            this.cksetprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.twoseta_lbl = new System.Windows.Forms.Label();
            this.twosetaprc_lbl = new System.Windows.Forms.Label();
            this.sidepage = new System.Windows.Forms.TabPage();
            this.tab_Panel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.ckgasside_lbl = new System.Windows.Forms.Label();
            this.ckgassideprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.chdonside_lbl = new System.Windows.Forms.Label();
            this.chdonsideprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.shrside_lbl = new System.Windows.Forms.Label();
            this.shrsideprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.ssgside_lbl = new System.Windows.Forms.Label();
            this.ssgsideprc_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.ckside_lbl = new System.Windows.Forms.Label();
            this.cksideprc_lbl = new System.Windows.Forms.Label();
            this.ssgside_btn = new System.Windows.Forms.Button();
            this.ckside_btn = new System.Windows.Forms.Button();
            this.crbside_btn = new System.Windows.Forms.Button();
            this.shrside_btn = new System.Windows.Forms.Button();
            this.chdonside_btn = new System.Windows.Forms.Button();
            this.ckgasside_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.crbside_lbl = new System.Windows.Forms.Label();
            this.crbsideprc_lbl = new System.Windows.Forms.Label();
            this.menu_panel = new System.Windows.Forms.TableLayoutPanel();
            this.currybtn = new System.Windows.Forms.Button();
            this.udonbtn = new System.Windows.Forms.Button();
            this.pastabtn = new System.Windows.Forms.Button();
            this.sidebtn = new System.Windows.Forms.Button();
            this.setbtn = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.del_btn = new System.Windows.Forms.Button();
            this.count_btn = new System.Windows.Forms.Button();
            this.return_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.tppslct_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.spcslct_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.chcroqtpp_ckbox = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.chstpp_ckbox = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.wlshtpp_ckbox = new System.Windows.Forms.CheckBox();
            this.grtpp_ckbox = new System.Windows.Forms.CheckBox();
            this.croqtpp_ckbox = new System.Windows.Forms.CheckBox();
            this.eggtpp_ckbox = new System.Windows.Forms.CheckBox();
            this.tppslct2_lbl = new System.Windows.Forms.Label();
            this.tppend_btn = new System.Windows.Forms.Button();
            this.slctprice_txt = new System.Windows.Forms.TextBox();
            this.price_lbl = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.slct_txt = new System.Windows.Forms.TextBox();
            this.main_panel.SuspendLayout();
            this.menutab.SuspendLayout();
            this.currypage.SuspendLayout();
            this.tab_Panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.udonpage.SuspendLayout();
            this.tab_Panel2.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.pastapage.SuspendLayout();
            this.tab_Panel3.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.setpage.SuspendLayout();
            this.tab_Panel4.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.sidepage.SuspendLayout();
            this.tab_Panel5.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.menu_panel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // main_panel
            // 
            this.main_panel.ColumnCount = 1;
            this.main_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.main_panel.Controls.Add(this.menutab, 0, 1);
            this.main_panel.Controls.Add(this.menu_panel, 0, 0);
            this.main_panel.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.main_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_panel.Location = new System.Drawing.Point(3, 3);
            this.main_panel.Name = "main_panel";
            this.main_panel.RowCount = 3;
            this.main_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.main_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.main_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.main_panel.Size = new System.Drawing.Size(664, 711);
            this.main_panel.TabIndex = 0;
            // 
            // menutab
            // 
            this.menutab.Controls.Add(this.currypage);
            this.menutab.Controls.Add(this.udonpage);
            this.menutab.Controls.Add(this.pastapage);
            this.menutab.Controls.Add(this.setpage);
            this.menutab.Controls.Add(this.sidepage);
            this.menutab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menutab.Location = new System.Drawing.Point(3, 74);
            this.menutab.Name = "menutab";
            this.menutab.SelectedIndex = 0;
            this.menutab.Size = new System.Drawing.Size(658, 456);
            this.menutab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.menutab.TabIndex = 0;
            // 
            // currypage
            // 
            this.currypage.AutoScroll = true;
            this.currypage.Controls.Add(this.tab_Panel1);
            this.currypage.Location = new System.Drawing.Point(4, 22);
            this.currypage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.currypage.Name = "currypage";
            this.currypage.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.currypage.Size = new System.Drawing.Size(650, 430);
            this.currypage.TabIndex = 0;
            // 
            // tab_Panel1
            // 
            this.tab_Panel1.ColumnCount = 3;
            this.tab_Panel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tab_Panel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel1.Controls.Add(this.mncrry_btn, 0, 0);
            this.tab_Panel1.Controls.Add(this.hbckcrry_btn, 1, 2);
            this.tab_Panel1.Controls.Add(this.sfcrry_btn, 2, 2);
            this.tab_Panel1.Controls.Add(this.frkcrry_btn, 1, 0);
            this.tab_Panel1.Controls.Add(this.bfcrry_btn, 2, 0);
            this.tab_Panel1.Controls.Add(this.shrcrry_btn, 0, 2);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel4, 1, 1);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel5, 2, 1);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel6, 0, 3);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel7, 1, 3);
            this.tab_Panel1.Controls.Add(this.tableLayoutPanel8, 2, 3);
            this.tab_Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Panel1.Location = new System.Drawing.Point(4, 3);
            this.tab_Panel1.Name = "tab_Panel1";
            this.tab_Panel1.RowCount = 4;
            this.tab_Panel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tab_Panel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.185803F));
            this.tab_Panel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.50105F));
            this.tab_Panel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tab_Panel1.Size = new System.Drawing.Size(642, 424);
            this.tab_Panel1.TabIndex = 1;
            // 
            // mncrry_btn
            // 
            this.mncrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mncrry_btn.BackgroundImage")));
            this.mncrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mncrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mncrry_btn.Location = new System.Drawing.Point(3, 3);
            this.mncrry_btn.Name = "mncrry_btn";
            this.mncrry_btn.Size = new System.Drawing.Size(207, 164);
            this.mncrry_btn.TabIndex = 0;
            this.mncrry_btn.UseVisualStyleBackColor = true;
            this.mncrry_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // hbckcrry_btn
            // 
            this.hbckcrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hbckcrry_btn.BackgroundImage")));
            this.hbckcrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hbckcrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckcrry_btn.Location = new System.Drawing.Point(216, 212);
            this.hbckcrry_btn.Name = "hbckcrry_btn";
            this.hbckcrry_btn.Size = new System.Drawing.Size(208, 166);
            this.hbckcrry_btn.TabIndex = 4;
            this.hbckcrry_btn.UseVisualStyleBackColor = true;
            this.hbckcrry_btn.Click += new System.EventHandler(this.button5_Click);
            // 
            // sfcrry_btn
            // 
            this.sfcrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sfcrry_btn.BackgroundImage")));
            this.sfcrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sfcrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfcrry_btn.Location = new System.Drawing.Point(430, 212);
            this.sfcrry_btn.Name = "sfcrry_btn";
            this.sfcrry_btn.Size = new System.Drawing.Size(209, 166);
            this.sfcrry_btn.TabIndex = 5;
            this.sfcrry_btn.UseVisualStyleBackColor = true;
            this.sfcrry_btn.Click += new System.EventHandler(this.button6_Click);
            // 
            // frkcrry_btn
            // 
            this.frkcrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("frkcrry_btn.BackgroundImage")));
            this.frkcrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.frkcrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frkcrry_btn.Location = new System.Drawing.Point(216, 3);
            this.frkcrry_btn.Name = "frkcrry_btn";
            this.frkcrry_btn.Size = new System.Drawing.Size(208, 164);
            this.frkcrry_btn.TabIndex = 1;
            this.frkcrry_btn.UseVisualStyleBackColor = true;
            this.frkcrry_btn.Click += new System.EventHandler(this.button2_Click);
            // 
            // bfcrry_btn
            // 
            this.bfcrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bfcrry_btn.BackgroundImage")));
            this.bfcrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bfcrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfcrry_btn.Location = new System.Drawing.Point(430, 3);
            this.bfcrry_btn.Name = "bfcrry_btn";
            this.bfcrry_btn.Size = new System.Drawing.Size(209, 164);
            this.bfcrry_btn.TabIndex = 2;
            this.bfcrry_btn.UseVisualStyleBackColor = true;
            this.bfcrry_btn.Click += new System.EventHandler(this.button3_Click);
            // 
            // shrcrry_btn
            // 
            this.shrcrry_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("shrcrry_btn.BackgroundImage")));
            this.shrcrry_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.shrcrry_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrcrry_btn.Location = new System.Drawing.Point(3, 212);
            this.shrcrry_btn.Name = "shrcrry_btn";
            this.shrcrry_btn.Size = new System.Drawing.Size(207, 166);
            this.shrcrry_btn.TabIndex = 3;
            this.shrcrry_btn.UseVisualStyleBackColor = true;
            this.shrcrry_btn.Click += new System.EventHandler(this.button4_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel3.Controls.Add(this.mncrry_lbl, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.mncrryprc_lbl, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 173);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(207, 33);
            this.tableLayoutPanel3.TabIndex = 12;
            // 
            // mncrry_lbl
            // 
            this.mncrry_lbl.AutoSize = true;
            this.mncrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mncrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.mncrry_lbl.Name = "mncrry_lbl";
            this.mncrry_lbl.Size = new System.Drawing.Size(118, 33);
            this.mncrry_lbl.TabIndex = 6;
            this.mncrry_lbl.Text = "기본 카레라이스";
            this.mncrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mncrry_lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // mncrryprc_lbl
            // 
            this.mncrryprc_lbl.AutoSize = true;
            this.mncrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mncrryprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.mncrryprc_lbl.Name = "mncrryprc_lbl";
            this.mncrryprc_lbl.Size = new System.Drawing.Size(77, 33);
            this.mncrryprc_lbl.TabIndex = 7;
            this.mncrryprc_lbl.Text = "5000";
            this.mncrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel4.Controls.Add(this.fkcrryprc_lbl, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.frkcrry_lbl, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(216, 173);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(208, 33);
            this.tableLayoutPanel4.TabIndex = 13;
            // 
            // fkcrryprc_lbl
            // 
            this.fkcrryprc_lbl.AutoSize = true;
            this.fkcrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fkcrryprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.fkcrryprc_lbl.Name = "fkcrryprc_lbl";
            this.fkcrryprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.fkcrryprc_lbl.TabIndex = 8;
            this.fkcrryprc_lbl.Text = "5500";
            this.fkcrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frkcrry_lbl
            // 
            this.frkcrry_lbl.AutoSize = true;
            this.frkcrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frkcrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.frkcrry_lbl.Name = "frkcrry_lbl";
            this.frkcrry_lbl.Size = new System.Drawing.Size(118, 33);
            this.frkcrry_lbl.TabIndex = 7;
            this.frkcrry_lbl.Text = "포크 카레라이스";
            this.frkcrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.frkcrry_lbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel5.Controls.Add(this.bfcrryprc_lbl, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.bfcrry_lbl, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(430, 173);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(209, 33);
            this.tableLayoutPanel5.TabIndex = 14;
            // 
            // bfcrryprc_lbl
            // 
            this.bfcrryprc_lbl.AutoSize = true;
            this.bfcrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfcrryprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.bfcrryprc_lbl.Name = "bfcrryprc_lbl";
            this.bfcrryprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.bfcrryprc_lbl.TabIndex = 9;
            this.bfcrryprc_lbl.Text = "5500";
            this.bfcrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bfcrry_lbl
            // 
            this.bfcrry_lbl.AutoSize = true;
            this.bfcrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfcrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.bfcrry_lbl.Name = "bfcrry_lbl";
            this.bfcrry_lbl.Size = new System.Drawing.Size(119, 33);
            this.bfcrry_lbl.TabIndex = 8;
            this.bfcrry_lbl.Text = "비프 카레라이스";
            this.bfcrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bfcrry_lbl.Click += new System.EventHandler(this.label3_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel6.Controls.Add(this.shrcrryprc_lbl, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.shrcrry_lbl, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 384);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(207, 37);
            this.tableLayoutPanel6.TabIndex = 15;
            // 
            // shrcrryprc_lbl
            // 
            this.shrcrryprc_lbl.AutoSize = true;
            this.shrcrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrcrryprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.shrcrryprc_lbl.Name = "shrcrryprc_lbl";
            this.shrcrryprc_lbl.Size = new System.Drawing.Size(77, 37);
            this.shrcrryprc_lbl.TabIndex = 10;
            this.shrcrryprc_lbl.Text = "6000";
            this.shrcrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shrcrry_lbl
            // 
            this.shrcrry_lbl.AutoSize = true;
            this.shrcrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrcrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.shrcrry_lbl.Name = "shrcrry_lbl";
            this.shrcrry_lbl.Size = new System.Drawing.Size(118, 37);
            this.shrcrry_lbl.TabIndex = 9;
            this.shrcrry_lbl.Text = "알새우 카레라이스";
            this.shrcrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.shrcrry_lbl.Click += new System.EventHandler(this.label4_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel7.Controls.Add(this.hbckcrryprc_lbl, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.hbckcrry_lbl, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(216, 384);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(208, 37);
            this.tableLayoutPanel7.TabIndex = 16;
            // 
            // hbckcrryprc_lbl
            // 
            this.hbckcrryprc_lbl.AutoSize = true;
            this.hbckcrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckcrryprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.hbckcrryprc_lbl.Name = "hbckcrryprc_lbl";
            this.hbckcrryprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.hbckcrryprc_lbl.TabIndex = 11;
            this.hbckcrryprc_lbl.Text = "6000";
            this.hbckcrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hbckcrry_lbl
            // 
            this.hbckcrry_lbl.AutoSize = true;
            this.hbckcrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckcrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.hbckcrry_lbl.Name = "hbckcrry_lbl";
            this.hbckcrry_lbl.Size = new System.Drawing.Size(118, 37);
            this.hbckcrry_lbl.TabIndex = 10;
            this.hbckcrry_lbl.Text = "허브치킨 카레라이스";
            this.hbckcrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hbckcrry_lbl.Click += new System.EventHandler(this.label5_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel8.Controls.Add(this.sfcrryprc_lbl, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.sfcrry_lbl, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(430, 384);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(209, 37);
            this.tableLayoutPanel8.TabIndex = 17;
            // 
            // sfcrryprc_lbl
            // 
            this.sfcrryprc_lbl.AutoSize = true;
            this.sfcrryprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfcrryprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.sfcrryprc_lbl.Name = "sfcrryprc_lbl";
            this.sfcrryprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.sfcrryprc_lbl.TabIndex = 12;
            this.sfcrryprc_lbl.Text = "6500";
            this.sfcrryprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfcrry_lbl
            // 
            this.sfcrry_lbl.AutoSize = true;
            this.sfcrry_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfcrry_lbl.Location = new System.Drawing.Point(3, 0);
            this.sfcrry_lbl.Name = "sfcrry_lbl";
            this.sfcrry_lbl.Size = new System.Drawing.Size(119, 37);
            this.sfcrry_lbl.TabIndex = 11;
            this.sfcrry_lbl.Text = "해산물 카레라이스";
            this.sfcrry_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sfcrry_lbl.Click += new System.EventHandler(this.label6_Click);
            // 
            // udonpage
            // 
            this.udonpage.AutoScroll = true;
            this.udonpage.Controls.Add(this.tab_Panel2);
            this.udonpage.Location = new System.Drawing.Point(4, 22);
            this.udonpage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.udonpage.Name = "udonpage";
            this.udonpage.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.udonpage.Size = new System.Drawing.Size(650, 430);
            this.udonpage.TabIndex = 1;
            // 
            // tab_Panel2
            // 
            this.tab_Panel2.ColumnCount = 3;
            this.tab_Panel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tab_Panel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel2.Controls.Add(this.bfudon_btn, 2, 0);
            this.tab_Panel2.Controls.Add(this.mshudon_btn, 1, 0);
            this.tab_Panel2.Controls.Add(this.mnudon_btn, 0, 0);
            this.tab_Panel2.Controls.Add(this.shrudon_btn, 0, 2);
            this.tab_Panel2.Controls.Add(this.sfudon_btn, 1, 2);
            this.tab_Panel2.Controls.Add(this.hbckudon_btn, 2, 2);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel15, 0, 1);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel16, 1, 1);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel17, 2, 1);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel18, 2, 3);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel19, 1, 3);
            this.tab_Panel2.Controls.Add(this.tableLayoutPanel20, 0, 3);
            this.tab_Panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Panel2.Location = new System.Drawing.Point(4, 3);
            this.tab_Panel2.Name = "tab_Panel2";
            this.tab_Panel2.RowCount = 4;
            this.tab_Panel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tab_Panel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.185803F));
            this.tab_Panel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.50105F));
            this.tab_Panel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tab_Panel2.Size = new System.Drawing.Size(642, 424);
            this.tab_Panel2.TabIndex = 2;
            // 
            // bfudon_btn
            // 
            this.bfudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bfudon_btn.BackgroundImage")));
            this.bfudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bfudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfudon_btn.Location = new System.Drawing.Point(430, 3);
            this.bfudon_btn.Name = "bfudon_btn";
            this.bfudon_btn.Size = new System.Drawing.Size(209, 164);
            this.bfudon_btn.TabIndex = 3;
            this.bfudon_btn.UseVisualStyleBackColor = true;
            this.bfudon_btn.Click += new System.EventHandler(this.bfudon_btn_Click);
            // 
            // mshudon_btn
            // 
            this.mshudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mshudon_btn.BackgroundImage")));
            this.mshudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mshudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshudon_btn.Location = new System.Drawing.Point(216, 3);
            this.mshudon_btn.Name = "mshudon_btn";
            this.mshudon_btn.Size = new System.Drawing.Size(208, 164);
            this.mshudon_btn.TabIndex = 2;
            this.mshudon_btn.UseVisualStyleBackColor = true;
            this.mshudon_btn.Click += new System.EventHandler(this.mshudon_btn_Click);
            // 
            // mnudon_btn
            // 
            this.mnudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mnudon_btn.BackgroundImage")));
            this.mnudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mnudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnudon_btn.Location = new System.Drawing.Point(3, 3);
            this.mnudon_btn.Name = "mnudon_btn";
            this.mnudon_btn.Size = new System.Drawing.Size(207, 164);
            this.mnudon_btn.TabIndex = 0;
            this.mnudon_btn.UseVisualStyleBackColor = true;
            this.mnudon_btn.Click += new System.EventHandler(this.mnudon_btn_Click);
            // 
            // shrudon_btn
            // 
            this.shrudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("shrudon_btn.BackgroundImage")));
            this.shrudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.shrudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrudon_btn.Location = new System.Drawing.Point(3, 212);
            this.shrudon_btn.Name = "shrudon_btn";
            this.shrudon_btn.Size = new System.Drawing.Size(207, 166);
            this.shrudon_btn.TabIndex = 1;
            this.shrudon_btn.UseVisualStyleBackColor = true;
            this.shrudon_btn.Click += new System.EventHandler(this.shrudon_btn_Click);
            // 
            // sfudon_btn
            // 
            this.sfudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sfudon_btn.BackgroundImage")));
            this.sfudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sfudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfudon_btn.Location = new System.Drawing.Point(216, 212);
            this.sfudon_btn.Name = "sfudon_btn";
            this.sfudon_btn.Size = new System.Drawing.Size(208, 166);
            this.sfudon_btn.TabIndex = 4;
            this.sfudon_btn.UseVisualStyleBackColor = true;
            this.sfudon_btn.Click += new System.EventHandler(this.sfudon_btn_Click);
            // 
            // hbckudon_btn
            // 
            this.hbckudon_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hbckudon_btn.BackgroundImage")));
            this.hbckudon_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hbckudon_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckudon_btn.Location = new System.Drawing.Point(430, 212);
            this.hbckudon_btn.Name = "hbckudon_btn";
            this.hbckudon_btn.Size = new System.Drawing.Size(209, 166);
            this.hbckudon_btn.TabIndex = 5;
            this.hbckudon_btn.UseVisualStyleBackColor = true;
            this.hbckudon_btn.Click += new System.EventHandler(this.hbckudon_btn_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel15.Controls.Add(this.mnudon_lbl, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.mnudonprc_lbl, 1, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 173);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(207, 33);
            this.tableLayoutPanel15.TabIndex = 12;
            // 
            // mnudon_lbl
            // 
            this.mnudon_lbl.AutoSize = true;
            this.mnudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.mnudon_lbl.Name = "mnudon_lbl";
            this.mnudon_lbl.Size = new System.Drawing.Size(118, 33);
            this.mnudon_lbl.TabIndex = 6;
            this.mnudon_lbl.Text = "기본 카레우동";
            this.mnudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mnudonprc_lbl
            // 
            this.mnudonprc_lbl.AutoSize = true;
            this.mnudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnudonprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.mnudonprc_lbl.Name = "mnudonprc_lbl";
            this.mnudonprc_lbl.Size = new System.Drawing.Size(77, 33);
            this.mnudonprc_lbl.TabIndex = 7;
            this.mnudonprc_lbl.Text = "4000";
            this.mnudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel16.Controls.Add(this.mshudonprc_lbl, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.mshudon_lbl, 0, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(216, 173);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(208, 33);
            this.tableLayoutPanel16.TabIndex = 13;
            // 
            // mshudonprc_lbl
            // 
            this.mshudonprc_lbl.AutoSize = true;
            this.mshudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshudonprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.mshudonprc_lbl.Name = "mshudonprc_lbl";
            this.mshudonprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.mshudonprc_lbl.TabIndex = 8;
            this.mshudonprc_lbl.Text = "5000";
            this.mshudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mshudon_lbl
            // 
            this.mshudon_lbl.AutoSize = true;
            this.mshudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.mshudon_lbl.Name = "mshudon_lbl";
            this.mshudon_lbl.Size = new System.Drawing.Size(118, 33);
            this.mshudon_lbl.TabIndex = 7;
            this.mshudon_lbl.Text = "버섯 카레우동";
            this.mshudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel17.Controls.Add(this.bfudonprc_lbl, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.bfudon_lbl, 0, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(430, 173);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(209, 33);
            this.tableLayoutPanel17.TabIndex = 14;
            // 
            // bfudonprc_lbl
            // 
            this.bfudonprc_lbl.AutoSize = true;
            this.bfudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfudonprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.bfudonprc_lbl.Name = "bfudonprc_lbl";
            this.bfudonprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.bfudonprc_lbl.TabIndex = 9;
            this.bfudonprc_lbl.Text = "5500";
            this.bfudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bfudon_lbl
            // 
            this.bfudon_lbl.AutoSize = true;
            this.bfudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.bfudon_lbl.Name = "bfudon_lbl";
            this.bfudon_lbl.Size = new System.Drawing.Size(119, 33);
            this.bfudon_lbl.TabIndex = 8;
            this.bfudon_lbl.Text = "비프 카레우동";
            this.bfudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel18.Controls.Add(this.hbckudonprc_lbl, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.hbckudon_lbl, 0, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(430, 384);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(209, 37);
            this.tableLayoutPanel18.TabIndex = 15;
            // 
            // hbckudonprc_lbl
            // 
            this.hbckudonprc_lbl.AutoSize = true;
            this.hbckudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckudonprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.hbckudonprc_lbl.Name = "hbckudonprc_lbl";
            this.hbckudonprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.hbckudonprc_lbl.TabIndex = 12;
            this.hbckudonprc_lbl.Text = "5000";
            this.hbckudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hbckudon_lbl
            // 
            this.hbckudon_lbl.AutoSize = true;
            this.hbckudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.hbckudon_lbl.Name = "hbckudon_lbl";
            this.hbckudon_lbl.Size = new System.Drawing.Size(119, 37);
            this.hbckudon_lbl.TabIndex = 11;
            this.hbckudon_lbl.Text = "허브치킨 카레우동";
            this.hbckudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel19.Controls.Add(this.sfudonprc_lbl, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.sfudon_lbl, 0, 0);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(216, 384);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 1;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(208, 37);
            this.tableLayoutPanel19.TabIndex = 16;
            // 
            // sfudonprc_lbl
            // 
            this.sfudonprc_lbl.AutoSize = true;
            this.sfudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfudonprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.sfudonprc_lbl.Name = "sfudonprc_lbl";
            this.sfudonprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.sfudonprc_lbl.TabIndex = 11;
            this.sfudonprc_lbl.Text = "5500";
            this.sfudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfudon_lbl
            // 
            this.sfudon_lbl.AutoSize = true;
            this.sfudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.sfudon_lbl.Name = "sfudon_lbl";
            this.sfudon_lbl.Size = new System.Drawing.Size(118, 37);
            this.sfudon_lbl.TabIndex = 10;
            this.sfudon_lbl.Text = "해산물 카레우동";
            this.sfudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel20.Controls.Add(this.shrudonprc_lbl, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.shrudon_lbl, 0, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 384);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(207, 37);
            this.tableLayoutPanel20.TabIndex = 17;
            // 
            // shrudonprc_lbl
            // 
            this.shrudonprc_lbl.AutoSize = true;
            this.shrudonprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrudonprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.shrudonprc_lbl.Name = "shrudonprc_lbl";
            this.shrudonprc_lbl.Size = new System.Drawing.Size(77, 37);
            this.shrudonprc_lbl.TabIndex = 10;
            this.shrudonprc_lbl.Text = "5500";
            this.shrudonprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shrudon_lbl
            // 
            this.shrudon_lbl.AutoSize = true;
            this.shrudon_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrudon_lbl.Location = new System.Drawing.Point(3, 0);
            this.shrudon_lbl.Name = "shrudon_lbl";
            this.shrudon_lbl.Size = new System.Drawing.Size(118, 37);
            this.shrudon_lbl.TabIndex = 9;
            this.shrudon_lbl.Text = "알새우 카레우동";
            this.shrudon_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pastapage
            // 
            this.pastapage.AutoScroll = true;
            this.pastapage.Controls.Add(this.tab_Panel3);
            this.pastapage.Location = new System.Drawing.Point(4, 22);
            this.pastapage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pastapage.Name = "pastapage";
            this.pastapage.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pastapage.Size = new System.Drawing.Size(650, 430);
            this.pastapage.TabIndex = 2;
            // 
            // tab_Panel3
            // 
            this.tab_Panel3.ColumnCount = 3;
            this.tab_Panel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tab_Panel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel3.Controls.Add(this.hbpst_btn, 2, 0);
            this.tab_Panel3.Controls.Add(this.mshpst_btn, 1, 0);
            this.tab_Panel3.Controls.Add(this.mnpst_btn, 0, 0);
            this.tab_Panel3.Controls.Add(this.hbckpst_btn, 0, 2);
            this.tab_Panel3.Controls.Add(this.tableLayoutPanel21, 0, 1);
            this.tab_Panel3.Controls.Add(this.tableLayoutPanel22, 1, 1);
            this.tab_Panel3.Controls.Add(this.tableLayoutPanel23, 2, 1);
            this.tab_Panel3.Controls.Add(this.tableLayoutPanel24, 0, 3);
            this.tab_Panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Panel3.Location = new System.Drawing.Point(4, 3);
            this.tab_Panel3.Name = "tab_Panel3";
            this.tab_Panel3.RowCount = 4;
            this.tab_Panel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tab_Panel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.185803F));
            this.tab_Panel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.50105F));
            this.tab_Panel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tab_Panel3.Size = new System.Drawing.Size(642, 424);
            this.tab_Panel3.TabIndex = 2;
            // 
            // hbpst_btn
            // 
            this.hbpst_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hbpst_btn.BackgroundImage")));
            this.hbpst_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hbpst_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbpst_btn.Location = new System.Drawing.Point(430, 3);
            this.hbpst_btn.Name = "hbpst_btn";
            this.hbpst_btn.Size = new System.Drawing.Size(209, 164);
            this.hbpst_btn.TabIndex = 3;
            this.hbpst_btn.UseVisualStyleBackColor = true;
            this.hbpst_btn.Click += new System.EventHandler(this.hbpst_btn_Click);
            // 
            // mshpst_btn
            // 
            this.mshpst_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mshpst_btn.BackgroundImage")));
            this.mshpst_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mshpst_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshpst_btn.Location = new System.Drawing.Point(216, 3);
            this.mshpst_btn.Name = "mshpst_btn";
            this.mshpst_btn.Size = new System.Drawing.Size(208, 164);
            this.mshpst_btn.TabIndex = 2;
            this.mshpst_btn.UseVisualStyleBackColor = true;
            this.mshpst_btn.Click += new System.EventHandler(this.mshpst_btn_Click);
            // 
            // mnpst_btn
            // 
            this.mnpst_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mnpst_btn.BackgroundImage")));
            this.mnpst_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mnpst_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnpst_btn.Location = new System.Drawing.Point(3, 3);
            this.mnpst_btn.Name = "mnpst_btn";
            this.mnpst_btn.Size = new System.Drawing.Size(207, 164);
            this.mnpst_btn.TabIndex = 0;
            this.mnpst_btn.UseVisualStyleBackColor = true;
            this.mnpst_btn.Click += new System.EventHandler(this.mnpst_btn_Click);
            // 
            // hbckpst_btn
            // 
            this.hbckpst_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hbckpst_btn.BackgroundImage")));
            this.hbckpst_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hbckpst_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckpst_btn.Location = new System.Drawing.Point(3, 212);
            this.hbckpst_btn.Name = "hbckpst_btn";
            this.hbckpst_btn.Size = new System.Drawing.Size(207, 166);
            this.hbckpst_btn.TabIndex = 1;
            this.hbckpst_btn.UseVisualStyleBackColor = true;
            this.hbckpst_btn.Click += new System.EventHandler(this.hbckpst_btn_Click);
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel21.Controls.Add(this.mnpst_lbl, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.mnpstprc_lbl, 1, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 173);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(207, 33);
            this.tableLayoutPanel21.TabIndex = 10;
            // 
            // mnpst_lbl
            // 
            this.mnpst_lbl.AutoSize = true;
            this.mnpst_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnpst_lbl.Location = new System.Drawing.Point(3, 0);
            this.mnpst_lbl.Name = "mnpst_lbl";
            this.mnpst_lbl.Size = new System.Drawing.Size(118, 33);
            this.mnpst_lbl.TabIndex = 6;
            this.mnpst_lbl.Text = "기본 크림카레\r\n파스타";
            this.mnpst_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mnpstprc_lbl
            // 
            this.mnpstprc_lbl.AutoSize = true;
            this.mnpstprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mnpstprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.mnpstprc_lbl.Name = "mnpstprc_lbl";
            this.mnpstprc_lbl.Size = new System.Drawing.Size(77, 33);
            this.mnpstprc_lbl.TabIndex = 7;
            this.mnpstprc_lbl.Text = "5500";
            this.mnpstprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel22.Controls.Add(this.mshpst_lbl, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.mshpstprc_lbl, 1, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(216, 173);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(208, 33);
            this.tableLayoutPanel22.TabIndex = 11;
            // 
            // mshpst_lbl
            // 
            this.mshpst_lbl.AutoSize = true;
            this.mshpst_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshpst_lbl.Location = new System.Drawing.Point(3, 0);
            this.mshpst_lbl.Name = "mshpst_lbl";
            this.mshpst_lbl.Size = new System.Drawing.Size(118, 33);
            this.mshpst_lbl.TabIndex = 7;
            this.mshpst_lbl.Text = "버섯 크림카레\r\n파스타";
            this.mshpst_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mshpstprc_lbl
            // 
            this.mshpstprc_lbl.AutoSize = true;
            this.mshpstprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mshpstprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.mshpstprc_lbl.Name = "mshpstprc_lbl";
            this.mshpstprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.mshpstprc_lbl.TabIndex = 8;
            this.mshpstprc_lbl.Text = "6000";
            this.mshpstprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel23.Controls.Add(this.hbpst_lbl, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.hbpstprc_lbl, 1, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(430, 173);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(209, 33);
            this.tableLayoutPanel23.TabIndex = 12;
            // 
            // hbpst_lbl
            // 
            this.hbpst_lbl.AutoSize = true;
            this.hbpst_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbpst_lbl.Location = new System.Drawing.Point(3, 0);
            this.hbpst_lbl.Name = "hbpst_lbl";
            this.hbpst_lbl.Size = new System.Drawing.Size(119, 33);
            this.hbpst_lbl.TabIndex = 8;
            this.hbpst_lbl.Text = "함박 크림카레\r\n파스타";
            this.hbpst_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hbpstprc_lbl
            // 
            this.hbpstprc_lbl.AutoSize = true;
            this.hbpstprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbpstprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.hbpstprc_lbl.Name = "hbpstprc_lbl";
            this.hbpstprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.hbpstprc_lbl.TabIndex = 9;
            this.hbpstprc_lbl.Text = "6500";
            this.hbpstprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel24.Controls.Add(this.hbckpst_lbl, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.hbckpstprc_lbl, 1, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(3, 384);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(207, 37);
            this.tableLayoutPanel24.TabIndex = 13;
            // 
            // hbckpst_lbl
            // 
            this.hbckpst_lbl.AutoSize = true;
            this.hbckpst_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckpst_lbl.Location = new System.Drawing.Point(3, 0);
            this.hbckpst_lbl.Name = "hbckpst_lbl";
            this.hbckpst_lbl.Size = new System.Drawing.Size(118, 37);
            this.hbckpst_lbl.TabIndex = 9;
            this.hbckpst_lbl.Text = "허브치킨 크림카레\r\n파스타";
            this.hbckpst_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hbckpstprc_lbl
            // 
            this.hbckpstprc_lbl.AutoSize = true;
            this.hbckpstprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hbckpstprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.hbckpstprc_lbl.Name = "hbckpstprc_lbl";
            this.hbckpstprc_lbl.Size = new System.Drawing.Size(77, 37);
            this.hbckpstprc_lbl.TabIndex = 10;
            this.hbckpstprc_lbl.Text = "6500";
            this.hbckpstprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // setpage
            // 
            this.setpage.AutoScroll = true;
            this.setpage.Controls.Add(this.tab_Panel4);
            this.setpage.Location = new System.Drawing.Point(4, 22);
            this.setpage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.setpage.Name = "setpage";
            this.setpage.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.setpage.Size = new System.Drawing.Size(650, 430);
            this.setpage.TabIndex = 3;
            // 
            // tab_Panel4
            // 
            this.tab_Panel4.ColumnCount = 3;
            this.tab_Panel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tab_Panel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel30, 0, 3);
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel29, 2, 3);
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel27, 2, 1);
            this.tab_Panel4.Controls.Add(this.fkset_btn, 2, 0);
            this.tab_Panel4.Controls.Add(this.ckset_btn, 1, 0);
            this.tab_Panel4.Controls.Add(this.bfset_btn, 0, 0);
            this.tab_Panel4.Controls.Add(this.sfset_btn, 0, 2);
            this.tab_Panel4.Controls.Add(this.twoseta_btn, 1, 2);
            this.tab_Panel4.Controls.Add(this.twosetb_btn, 2, 2);
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel25, 0, 1);
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel26, 1, 1);
            this.tab_Panel4.Controls.Add(this.tableLayoutPanel28, 1, 3);
            this.tab_Panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Panel4.Location = new System.Drawing.Point(4, 3);
            this.tab_Panel4.Name = "tab_Panel4";
            this.tab_Panel4.RowCount = 4;
            this.tab_Panel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tab_Panel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.185803F));
            this.tab_Panel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.50105F));
            this.tab_Panel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tab_Panel4.Size = new System.Drawing.Size(642, 424);
            this.tab_Panel4.TabIndex = 2;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel30.Controls.Add(this.sfset_lbl, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.sfsetprc_lbl, 1, 0);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 384);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(207, 37);
            this.tableLayoutPanel30.TabIndex = 17;
            // 
            // sfset_lbl
            // 
            this.sfset_lbl.AutoSize = true;
            this.sfset_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfset_lbl.Location = new System.Drawing.Point(3, 0);
            this.sfset_lbl.Name = "sfset_lbl";
            this.sfset_lbl.Size = new System.Drawing.Size(118, 37);
            this.sfset_lbl.TabIndex = 9;
            this.sfset_lbl.Text = "해산물 세트";
            this.sfset_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfsetprc_lbl
            // 
            this.sfsetprc_lbl.AutoSize = true;
            this.sfsetprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfsetprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.sfsetprc_lbl.Name = "sfsetprc_lbl";
            this.sfsetprc_lbl.Size = new System.Drawing.Size(77, 37);
            this.sfsetprc_lbl.TabIndex = 10;
            this.sfsetprc_lbl.Text = "8000";
            this.sfsetprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel29.Controls.Add(this.twosetb_lbl, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.twosetbprc_lbl, 1, 0);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(430, 384);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(209, 37);
            this.tableLayoutPanel29.TabIndex = 16;
            // 
            // twosetb_lbl
            // 
            this.twosetb_lbl.AutoSize = true;
            this.twosetb_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twosetb_lbl.Location = new System.Drawing.Point(3, 0);
            this.twosetb_lbl.Name = "twosetb_lbl";
            this.twosetb_lbl.Size = new System.Drawing.Size(119, 37);
            this.twosetb_lbl.TabIndex = 11;
            this.twosetb_lbl.Text = "2인 세트B";
            this.twosetb_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twosetbprc_lbl
            // 
            this.twosetbprc_lbl.AutoSize = true;
            this.twosetbprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twosetbprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.twosetbprc_lbl.Name = "twosetbprc_lbl";
            this.twosetbprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.twosetbprc_lbl.TabIndex = 12;
            this.twosetbprc_lbl.Text = "15000";
            this.twosetbprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel27.Controls.Add(this.fkset_lbl, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.fksetprc_lbl, 1, 0);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(430, 173);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(209, 33);
            this.tableLayoutPanel27.TabIndex = 14;
            // 
            // fkset_lbl
            // 
            this.fkset_lbl.AutoSize = true;
            this.fkset_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fkset_lbl.Location = new System.Drawing.Point(3, 0);
            this.fkset_lbl.Name = "fkset_lbl";
            this.fkset_lbl.Size = new System.Drawing.Size(119, 33);
            this.fkset_lbl.TabIndex = 8;
            this.fkset_lbl.Text = "포크 세트";
            this.fkset_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fksetprc_lbl
            // 
            this.fksetprc_lbl.AutoSize = true;
            this.fksetprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fksetprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.fksetprc_lbl.Name = "fksetprc_lbl";
            this.fksetprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.fksetprc_lbl.TabIndex = 9;
            this.fksetprc_lbl.Text = "8000";
            this.fksetprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fkset_btn
            // 
            this.fkset_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fkset_btn.BackgroundImage")));
            this.fkset_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fkset_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fkset_btn.Location = new System.Drawing.Point(430, 3);
            this.fkset_btn.Name = "fkset_btn";
            this.fkset_btn.Size = new System.Drawing.Size(209, 164);
            this.fkset_btn.TabIndex = 3;
            this.fkset_btn.UseVisualStyleBackColor = true;
            this.fkset_btn.Click += new System.EventHandler(this.fkset_btn_Click);
            // 
            // ckset_btn
            // 
            this.ckset_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ckset_btn.BackgroundImage")));
            this.ckset_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ckset_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckset_btn.Location = new System.Drawing.Point(216, 3);
            this.ckset_btn.Name = "ckset_btn";
            this.ckset_btn.Size = new System.Drawing.Size(208, 164);
            this.ckset_btn.TabIndex = 2;
            this.ckset_btn.UseVisualStyleBackColor = true;
            this.ckset_btn.Click += new System.EventHandler(this.ckset_btn_Click);
            // 
            // bfset_btn
            // 
            this.bfset_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bfset_btn.BackgroundImage")));
            this.bfset_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bfset_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfset_btn.Location = new System.Drawing.Point(3, 3);
            this.bfset_btn.Name = "bfset_btn";
            this.bfset_btn.Size = new System.Drawing.Size(207, 164);
            this.bfset_btn.TabIndex = 0;
            this.bfset_btn.UseVisualStyleBackColor = true;
            this.bfset_btn.Click += new System.EventHandler(this.bfset_btn_Click);
            // 
            // sfset_btn
            // 
            this.sfset_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sfset_btn.BackgroundImage")));
            this.sfset_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sfset_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfset_btn.Location = new System.Drawing.Point(3, 212);
            this.sfset_btn.Name = "sfset_btn";
            this.sfset_btn.Size = new System.Drawing.Size(207, 166);
            this.sfset_btn.TabIndex = 1;
            this.sfset_btn.UseVisualStyleBackColor = true;
            this.sfset_btn.Click += new System.EventHandler(this.sfset_btn_Click);
            // 
            // twoseta_btn
            // 
            this.twoseta_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("twoseta_btn.BackgroundImage")));
            this.twoseta_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.twoseta_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twoseta_btn.Location = new System.Drawing.Point(216, 212);
            this.twoseta_btn.Name = "twoseta_btn";
            this.twoseta_btn.Size = new System.Drawing.Size(208, 166);
            this.twoseta_btn.TabIndex = 4;
            this.twoseta_btn.UseVisualStyleBackColor = true;
            this.twoseta_btn.Click += new System.EventHandler(this.twoseta_btn_Click);
            // 
            // twosetb_btn
            // 
            this.twosetb_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("twosetb_btn.BackgroundImage")));
            this.twosetb_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.twosetb_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twosetb_btn.Location = new System.Drawing.Point(430, 212);
            this.twosetb_btn.Name = "twosetb_btn";
            this.twosetb_btn.Size = new System.Drawing.Size(209, 166);
            this.twosetb_btn.TabIndex = 5;
            this.twosetb_btn.UseVisualStyleBackColor = true;
            this.twosetb_btn.Click += new System.EventHandler(this.twosetb_btn_Click);
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel25.Controls.Add(this.bfset_lbl, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.bfsetprc_lbl, 1, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 173);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(207, 33);
            this.tableLayoutPanel25.TabIndex = 12;
            // 
            // bfset_lbl
            // 
            this.bfset_lbl.AutoSize = true;
            this.bfset_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfset_lbl.Location = new System.Drawing.Point(3, 0);
            this.bfset_lbl.Name = "bfset_lbl";
            this.bfset_lbl.Size = new System.Drawing.Size(118, 33);
            this.bfset_lbl.TabIndex = 6;
            this.bfset_lbl.Text = "비프 세트";
            this.bfset_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bfsetprc_lbl
            // 
            this.bfsetprc_lbl.AutoSize = true;
            this.bfsetprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bfsetprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.bfsetprc_lbl.Name = "bfsetprc_lbl";
            this.bfsetprc_lbl.Size = new System.Drawing.Size(77, 33);
            this.bfsetprc_lbl.TabIndex = 7;
            this.bfsetprc_lbl.Text = "7000";
            this.bfsetprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel26.Controls.Add(this.ckset_lbl, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.cksetprc_lbl, 1, 0);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(216, 173);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(208, 33);
            this.tableLayoutPanel26.TabIndex = 13;
            // 
            // ckset_lbl
            // 
            this.ckset_lbl.AutoSize = true;
            this.ckset_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckset_lbl.Location = new System.Drawing.Point(3, 0);
            this.ckset_lbl.Name = "ckset_lbl";
            this.ckset_lbl.Size = new System.Drawing.Size(118, 33);
            this.ckset_lbl.TabIndex = 7;
            this.ckset_lbl.Text = "치킨 세트";
            this.ckset_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cksetprc_lbl
            // 
            this.cksetprc_lbl.AutoSize = true;
            this.cksetprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cksetprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.cksetprc_lbl.Name = "cksetprc_lbl";
            this.cksetprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.cksetprc_lbl.TabIndex = 8;
            this.cksetprc_lbl.Text = "8500";
            this.cksetprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel28.Controls.Add(this.twoseta_lbl, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.twosetaprc_lbl, 1, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(216, 384);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(208, 37);
            this.tableLayoutPanel28.TabIndex = 15;
            // 
            // twoseta_lbl
            // 
            this.twoseta_lbl.AutoSize = true;
            this.twoseta_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twoseta_lbl.Location = new System.Drawing.Point(3, 0);
            this.twoseta_lbl.Name = "twoseta_lbl";
            this.twoseta_lbl.Size = new System.Drawing.Size(118, 37);
            this.twoseta_lbl.TabIndex = 10;
            this.twoseta_lbl.Text = "2인 세트A";
            this.twoseta_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twosetaprc_lbl
            // 
            this.twosetaprc_lbl.AutoSize = true;
            this.twosetaprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twosetaprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.twosetaprc_lbl.Name = "twosetaprc_lbl";
            this.twosetaprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.twosetaprc_lbl.TabIndex = 11;
            this.twosetaprc_lbl.Text = "15000";
            this.twosetaprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sidepage
            // 
            this.sidepage.AutoScroll = true;
            this.sidepage.Controls.Add(this.tab_Panel5);
            this.sidepage.Location = new System.Drawing.Point(4, 22);
            this.sidepage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.sidepage.Name = "sidepage";
            this.sidepage.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.sidepage.Size = new System.Drawing.Size(650, 430);
            this.sidepage.TabIndex = 4;
            // 
            // tab_Panel5
            // 
            this.tab_Panel5.ColumnCount = 3;
            this.tab_Panel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tab_Panel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel36, 2, 3);
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel35, 1, 3);
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel34, 0, 3);
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel33, 2, 1);
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel32, 1, 1);
            this.tab_Panel5.Controls.Add(this.ssgside_btn, 2, 0);
            this.tab_Panel5.Controls.Add(this.ckside_btn, 1, 0);
            this.tab_Panel5.Controls.Add(this.crbside_btn, 0, 0);
            this.tab_Panel5.Controls.Add(this.shrside_btn, 0, 2);
            this.tab_Panel5.Controls.Add(this.chdonside_btn, 1, 2);
            this.tab_Panel5.Controls.Add(this.ckgasside_btn, 2, 2);
            this.tab_Panel5.Controls.Add(this.tableLayoutPanel31, 0, 1);
            this.tab_Panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Panel5.Location = new System.Drawing.Point(4, 3);
            this.tab_Panel5.Name = "tab_Panel5";
            this.tab_Panel5.RowCount = 4;
            this.tab_Panel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tab_Panel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.185803F));
            this.tab_Panel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.50105F));
            this.tab_Panel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tab_Panel5.Size = new System.Drawing.Size(642, 424);
            this.tab_Panel5.TabIndex = 3;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel36.Controls.Add(this.ckgasside_lbl, 0, 0);
            this.tableLayoutPanel36.Controls.Add(this.ckgassideprc_lbl, 1, 0);
            this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(430, 384);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(209, 37);
            this.tableLayoutPanel36.TabIndex = 17;
            // 
            // ckgasside_lbl
            // 
            this.ckgasside_lbl.AutoSize = true;
            this.ckgasside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckgasside_lbl.Location = new System.Drawing.Point(3, 0);
            this.ckgasside_lbl.Name = "ckgasside_lbl";
            this.ckgasside_lbl.Size = new System.Drawing.Size(119, 37);
            this.ckgasside_lbl.TabIndex = 11;
            this.ckgasside_lbl.Text = "치킨가스";
            this.ckgasside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ckgassideprc_lbl
            // 
            this.ckgassideprc_lbl.AutoSize = true;
            this.ckgassideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckgassideprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.ckgassideprc_lbl.Name = "ckgassideprc_lbl";
            this.ckgassideprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.ckgassideprc_lbl.TabIndex = 12;
            this.ckgassideprc_lbl.Text = "3000";
            this.ckgassideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 2;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel35.Controls.Add(this.chdonside_lbl, 0, 0);
            this.tableLayoutPanel35.Controls.Add(this.chdonsideprc_lbl, 1, 0);
            this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(216, 384);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(208, 37);
            this.tableLayoutPanel35.TabIndex = 16;
            // 
            // chdonside_lbl
            // 
            this.chdonside_lbl.AutoSize = true;
            this.chdonside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chdonside_lbl.Location = new System.Drawing.Point(3, 0);
            this.chdonside_lbl.Name = "chdonside_lbl";
            this.chdonside_lbl.Size = new System.Drawing.Size(118, 37);
            this.chdonside_lbl.TabIndex = 10;
            this.chdonside_lbl.Text = "치즈돈가스";
            this.chdonside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chdonsideprc_lbl
            // 
            this.chdonsideprc_lbl.AutoSize = true;
            this.chdonsideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chdonsideprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.chdonsideprc_lbl.Name = "chdonsideprc_lbl";
            this.chdonsideprc_lbl.Size = new System.Drawing.Size(78, 37);
            this.chdonsideprc_lbl.TabIndex = 11;
            this.chdonsideprc_lbl.Text = "3500";
            this.chdonsideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel34.Controls.Add(this.shrside_lbl, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.shrsideprc_lbl, 1, 0);
            this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(3, 384);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(207, 37);
            this.tableLayoutPanel34.TabIndex = 15;
            // 
            // shrside_lbl
            // 
            this.shrside_lbl.AutoSize = true;
            this.shrside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrside_lbl.Location = new System.Drawing.Point(3, 0);
            this.shrside_lbl.Name = "shrside_lbl";
            this.shrside_lbl.Size = new System.Drawing.Size(118, 37);
            this.shrside_lbl.TabIndex = 9;
            this.shrside_lbl.Text = "왕새우튀김";
            this.shrside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shrsideprc_lbl
            // 
            this.shrsideprc_lbl.AutoSize = true;
            this.shrsideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrsideprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.shrsideprc_lbl.Name = "shrsideprc_lbl";
            this.shrsideprc_lbl.Size = new System.Drawing.Size(77, 37);
            this.shrsideprc_lbl.TabIndex = 10;
            this.shrsideprc_lbl.Text = "2500";
            this.shrsideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel33.Controls.Add(this.ssgside_lbl, 0, 0);
            this.tableLayoutPanel33.Controls.Add(this.ssgsideprc_lbl, 1, 0);
            this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(430, 173);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(209, 33);
            this.tableLayoutPanel33.TabIndex = 14;
            // 
            // ssgside_lbl
            // 
            this.ssgside_lbl.AutoSize = true;
            this.ssgside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ssgside_lbl.Location = new System.Drawing.Point(3, 0);
            this.ssgside_lbl.Name = "ssgside_lbl";
            this.ssgside_lbl.Size = new System.Drawing.Size(119, 33);
            this.ssgside_lbl.TabIndex = 8;
            this.ssgside_lbl.Text = "프리미엄 소시지";
            this.ssgside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ssgsideprc_lbl
            // 
            this.ssgsideprc_lbl.AutoSize = true;
            this.ssgsideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ssgsideprc_lbl.Location = new System.Drawing.Point(128, 0);
            this.ssgsideprc_lbl.Name = "ssgsideprc_lbl";
            this.ssgsideprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.ssgsideprc_lbl.TabIndex = 9;
            this.ssgsideprc_lbl.Text = "2000";
            this.ssgsideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel32.Controls.Add(this.ckside_lbl, 0, 0);
            this.tableLayoutPanel32.Controls.Add(this.cksideprc_lbl, 1, 0);
            this.tableLayoutPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(216, 173);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(208, 33);
            this.tableLayoutPanel32.TabIndex = 13;
            // 
            // ckside_lbl
            // 
            this.ckside_lbl.AutoSize = true;
            this.ckside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckside_lbl.Location = new System.Drawing.Point(3, 0);
            this.ckside_lbl.Name = "ckside_lbl";
            this.ckside_lbl.Size = new System.Drawing.Size(118, 33);
            this.ckside_lbl.TabIndex = 7;
            this.ckside_lbl.Text = "닭 가라아게";
            this.ckside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cksideprc_lbl
            // 
            this.cksideprc_lbl.AutoSize = true;
            this.cksideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cksideprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.cksideprc_lbl.Name = "cksideprc_lbl";
            this.cksideprc_lbl.Size = new System.Drawing.Size(78, 33);
            this.cksideprc_lbl.TabIndex = 8;
            this.cksideprc_lbl.Text = "2000";
            this.cksideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ssgside_btn
            // 
            this.ssgside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ssgside_btn.BackgroundImage")));
            this.ssgside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ssgside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ssgside_btn.Location = new System.Drawing.Point(430, 3);
            this.ssgside_btn.Name = "ssgside_btn";
            this.ssgside_btn.Size = new System.Drawing.Size(209, 164);
            this.ssgside_btn.TabIndex = 3;
            this.ssgside_btn.UseVisualStyleBackColor = true;
            this.ssgside_btn.Click += new System.EventHandler(this.ssgside_btn_Click);
            // 
            // ckside_btn
            // 
            this.ckside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ckside_btn.BackgroundImage")));
            this.ckside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ckside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckside_btn.Location = new System.Drawing.Point(216, 3);
            this.ckside_btn.Name = "ckside_btn";
            this.ckside_btn.Size = new System.Drawing.Size(208, 164);
            this.ckside_btn.TabIndex = 2;
            this.ckside_btn.UseVisualStyleBackColor = true;
            this.ckside_btn.Click += new System.EventHandler(this.ckside_btn_Click);
            // 
            // crbside_btn
            // 
            this.crbside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("crbside_btn.BackgroundImage")));
            this.crbside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.crbside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crbside_btn.Location = new System.Drawing.Point(3, 3);
            this.crbside_btn.Name = "crbside_btn";
            this.crbside_btn.Size = new System.Drawing.Size(207, 164);
            this.crbside_btn.TabIndex = 0;
            this.crbside_btn.UseVisualStyleBackColor = true;
            this.crbside_btn.Click += new System.EventHandler(this.crbside_btn_Click);
            // 
            // shrside_btn
            // 
            this.shrside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("shrside_btn.BackgroundImage")));
            this.shrside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.shrside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shrside_btn.Location = new System.Drawing.Point(3, 212);
            this.shrside_btn.Name = "shrside_btn";
            this.shrside_btn.Size = new System.Drawing.Size(207, 166);
            this.shrside_btn.TabIndex = 1;
            this.shrside_btn.UseVisualStyleBackColor = true;
            this.shrside_btn.Click += new System.EventHandler(this.shrside_btn_Click);
            // 
            // chdonside_btn
            // 
            this.chdonside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chdonside_btn.BackgroundImage")));
            this.chdonside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chdonside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chdonside_btn.Location = new System.Drawing.Point(216, 212);
            this.chdonside_btn.Name = "chdonside_btn";
            this.chdonside_btn.Size = new System.Drawing.Size(208, 166);
            this.chdonside_btn.TabIndex = 4;
            this.chdonside_btn.UseVisualStyleBackColor = true;
            this.chdonside_btn.Click += new System.EventHandler(this.chdonside_btn_Click);
            // 
            // ckgasside_btn
            // 
            this.ckgasside_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ckgasside_btn.BackgroundImage")));
            this.ckgasside_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ckgasside_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ckgasside_btn.Location = new System.Drawing.Point(430, 212);
            this.ckgasside_btn.Name = "ckgasside_btn";
            this.ckgasside_btn.Size = new System.Drawing.Size(209, 166);
            this.ckgasside_btn.TabIndex = 5;
            this.ckgasside_btn.UseVisualStyleBackColor = true;
            this.ckgasside_btn.Click += new System.EventHandler(this.ckgasside_btn_Click);
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel31.Controls.Add(this.crbside_lbl, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.crbsideprc_lbl, 1, 0);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 173);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(207, 33);
            this.tableLayoutPanel31.TabIndex = 12;
            // 
            // crbside_lbl
            // 
            this.crbside_lbl.AutoSize = true;
            this.crbside_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crbside_lbl.Location = new System.Drawing.Point(3, 0);
            this.crbside_lbl.Name = "crbside_lbl";
            this.crbside_lbl.Size = new System.Drawing.Size(118, 33);
            this.crbside_lbl.TabIndex = 6;
            this.crbside_lbl.Text = "게살튀김";
            this.crbside_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // crbsideprc_lbl
            // 
            this.crbsideprc_lbl.AutoSize = true;
            this.crbsideprc_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crbsideprc_lbl.Location = new System.Drawing.Point(127, 0);
            this.crbsideprc_lbl.Name = "crbsideprc_lbl";
            this.crbsideprc_lbl.Size = new System.Drawing.Size(77, 33);
            this.crbsideprc_lbl.TabIndex = 7;
            this.crbsideprc_lbl.Text = "1500";
            this.crbsideprc_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menu_panel
            // 
            this.menu_panel.ColumnCount = 5;
            this.menu_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.Controls.Add(this.currybtn, 0, 1);
            this.menu_panel.Controls.Add(this.udonbtn, 1, 1);
            this.menu_panel.Controls.Add(this.pastabtn, 2, 1);
            this.menu_panel.Controls.Add(this.sidebtn, 4, 1);
            this.menu_panel.Controls.Add(this.setbtn, 3, 1);
            this.menu_panel.Controls.Add(this.label31, 4, 0);
            this.menu_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menu_panel.Location = new System.Drawing.Point(3, 3);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.RowCount = 2;
            this.menu_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.menu_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.menu_panel.Size = new System.Drawing.Size(658, 65);
            this.menu_panel.TabIndex = 1;
            // 
            // currybtn
            // 
            this.currybtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.currybtn.Location = new System.Drawing.Point(3, 16);
            this.currybtn.Name = "currybtn";
            this.currybtn.Size = new System.Drawing.Size(125, 46);
            this.currybtn.TabIndex = 0;
            this.currybtn.Text = "카레";
            this.currybtn.UseVisualStyleBackColor = true;
            this.currybtn.Click += new System.EventHandler(this.currybtn_Click);
            // 
            // udonbtn
            // 
            this.udonbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.udonbtn.Location = new System.Drawing.Point(134, 16);
            this.udonbtn.Name = "udonbtn";
            this.udonbtn.Size = new System.Drawing.Size(125, 46);
            this.udonbtn.TabIndex = 1;
            this.udonbtn.Text = "우동";
            this.udonbtn.UseVisualStyleBackColor = true;
            this.udonbtn.Click += new System.EventHandler(this.udonbtn_Click);
            // 
            // pastabtn
            // 
            this.pastabtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pastabtn.Location = new System.Drawing.Point(265, 16);
            this.pastabtn.Name = "pastabtn";
            this.pastabtn.Size = new System.Drawing.Size(125, 46);
            this.pastabtn.TabIndex = 2;
            this.pastabtn.Text = "파스타";
            this.pastabtn.UseVisualStyleBackColor = true;
            this.pastabtn.Click += new System.EventHandler(this.ricebtn_Click);
            // 
            // sidebtn
            // 
            this.sidebtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sidebtn.Location = new System.Drawing.Point(527, 16);
            this.sidebtn.Name = "sidebtn";
            this.sidebtn.Size = new System.Drawing.Size(128, 46);
            this.sidebtn.TabIndex = 3;
            this.sidebtn.Text = "사이드메뉴";
            this.sidebtn.UseVisualStyleBackColor = true;
            this.sidebtn.Click += new System.EventHandler(this.sidebtn_Click);
            // 
            // setbtn
            // 
            this.setbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.setbtn.Location = new System.Drawing.Point(396, 16);
            this.setbtn.Name = "setbtn";
            this.setbtn.Size = new System.Drawing.Size(125, 46);
            this.setbtn.TabIndex = 4;
            this.setbtn.Text = "세트";
            this.setbtn.UseVisualStyleBackColor = true;
            this.setbtn.Click += new System.EventHandler(this.setbtn_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(527, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(128, 13);
            this.label31.TabIndex = 5;
            this.label31.Text = "label31";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 536);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(658, 172);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(432, 166);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.del_btn, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.count_btn, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.return_btn, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(441, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(214, 166);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // del_btn
            // 
            this.del_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.del_btn.Location = new System.Drawing.Point(110, 3);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(101, 77);
            this.del_btn.TabIndex = 1;
            this.del_btn.Text = "삭제";
            this.del_btn.UseVisualStyleBackColor = true;
            this.del_btn.Click += new System.EventHandler(this.del_btn_Click);
            // 
            // count_btn
            // 
            this.count_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.count_btn.Location = new System.Drawing.Point(3, 3);
            this.count_btn.Name = "count_btn";
            this.count_btn.Size = new System.Drawing.Size(101, 77);
            this.count_btn.TabIndex = 0;
            this.count_btn.Text = "계산";
            this.count_btn.UseVisualStyleBackColor = true;
            this.count_btn.Click += new System.EventHandler(this.count_btn_Click);
            // 
            // return_btn
            // 
            this.return_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.return_btn.Location = new System.Drawing.Point(110, 86);
            this.return_btn.Name = "return_btn";
            this.return_btn.Size = new System.Drawing.Size(101, 77);
            this.return_btn.TabIndex = 2;
            this.return_btn.Text = "이전";
            this.return_btn.UseVisualStyleBackColor = true;
            this.return_btn.Click += new System.EventHandler(this.return_btn_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.tabControl1, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(684, 749);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(64, 18);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(678, 743);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.main_panel);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(670, 717);
            this.tabPage1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.tableLayoutPanel10);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(670, 717);
            this.tabPage2.TabIndex = 1;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel10.Controls.Add(this.tppslct_lbl, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel11, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.tppend_btn, 2, 2);
            this.tableLayoutPanel10.Controls.Add(this.slctprice_txt, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.price_lbl, 2, 1);
            this.tableLayoutPanel10.Controls.Add(this.dataGridView2, 1, 2);
            this.tableLayoutPanel10.Controls.Add(this.slct_txt, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 4;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(664, 711);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // tppslct_lbl
            // 
            this.tppslct_lbl.AutoSize = true;
            this.tppslct_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tppslct_lbl.Location = new System.Drawing.Point(102, 0);
            this.tppslct_lbl.Name = "tppslct_lbl";
            this.tppslct_lbl.Size = new System.Drawing.Size(458, 103);
            this.tppslct_lbl.TabIndex = 0;
            this.tppslct_lbl.Text = "토핑을 선택해주세요";
            this.tppslct_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.spcslct_lbl, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel13, 0, 2);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(102, 106);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 3;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(458, 477);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // spcslct_lbl
            // 
            this.spcslct_lbl.AutoSize = true;
            this.spcslct_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcslct_lbl.Location = new System.Drawing.Point(3, 0);
            this.spcslct_lbl.Name = "spcslct_lbl";
            this.spcslct_lbl.Size = new System.Drawing.Size(452, 23);
            this.spcslct_lbl.TabIndex = 0;
            this.spcslct_lbl.Text = "매운맛을 선택하세요";
            this.spcslct_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 4;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.Controls.Add(this.radioButton4, 3, 0);
            this.tableLayoutPanel12.Controls.Add(this.radioButton3, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.radioButton2, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.radioButton1, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 26);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(452, 41);
            this.tableLayoutPanel12.TabIndex = 1;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton4.Location = new System.Drawing.Point(342, 3);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(107, 35);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "3단계";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton3.Location = new System.Drawing.Point(229, 3);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(107, 35);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "2단계";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton2.Location = new System.Drawing.Point(116, 3);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(107, 35);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "1단계";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton1.Location = new System.Drawing.Point(3, 3);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(107, 35);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "0단계";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel14, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.tppslct2_lbl, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 73);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 95F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(452, 401);
            this.tableLayoutPanel13.TabIndex = 2;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Controls.Add(this.chcroqtpp_ckbox, 2, 3);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox3, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox2, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox4, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox5, 1, 2);
            this.tableLayoutPanel14.Controls.Add(this.chstpp_ckbox, 2, 1);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox6, 2, 2);
            this.tableLayoutPanel14.Controls.Add(this.wlshtpp_ckbox, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.grtpp_ckbox, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.croqtpp_ckbox, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.eggtpp_ckbox, 0, 3);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 4;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(446, 375);
            this.tableLayoutPanel14.TabIndex = 2;
            // 
            // chcroqtpp_ckbox
            // 
            this.chcroqtpp_ckbox.AutoSize = true;
            this.chcroqtpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chcroqtpp_ckbox.Location = new System.Drawing.Point(299, 340);
            this.chcroqtpp_ckbox.Name = "chcroqtpp_ckbox";
            this.chcroqtpp_ckbox.Size = new System.Drawing.Size(144, 32);
            this.chcroqtpp_ckbox.TabIndex = 11;
            this.chcroqtpp_ckbox.Text = "치즈고로케";
            this.chcroqtpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chcroqtpp_ckbox.UseVisualStyleBackColor = true;
            this.chcroqtpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(299, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(144, 144);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(151, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(142, 144);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(142, 144);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 190);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(142, 144);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(151, 190);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(142, 144);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // chstpp_ckbox
            // 
            this.chstpp_ckbox.AutoSize = true;
            this.chstpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chstpp_ckbox.Location = new System.Drawing.Point(299, 153);
            this.chstpp_ckbox.Name = "chstpp_ckbox";
            this.chstpp_ckbox.Size = new System.Drawing.Size(144, 31);
            this.chstpp_ckbox.TabIndex = 8;
            this.chstpp_ckbox.Text = "멜탕치즈";
            this.chstpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chstpp_ckbox.UseVisualStyleBackColor = true;
            this.chstpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(299, 190);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(144, 144);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // wlshtpp_ckbox
            // 
            this.wlshtpp_ckbox.AutoSize = true;
            this.wlshtpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wlshtpp_ckbox.Location = new System.Drawing.Point(151, 153);
            this.wlshtpp_ckbox.Name = "wlshtpp_ckbox";
            this.wlshtpp_ckbox.Size = new System.Drawing.Size(142, 31);
            this.wlshtpp_ckbox.TabIndex = 7;
            this.wlshtpp_ckbox.Text = "아삭아삭 대파";
            this.wlshtpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.wlshtpp_ckbox.UseVisualStyleBackColor = true;
            this.wlshtpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // grtpp_ckbox
            // 
            this.grtpp_ckbox.AutoSize = true;
            this.grtpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grtpp_ckbox.Location = new System.Drawing.Point(3, 153);
            this.grtpp_ckbox.Name = "grtpp_ckbox";
            this.grtpp_ckbox.Size = new System.Drawing.Size(142, 31);
            this.grtpp_ckbox.TabIndex = 6;
            this.grtpp_ckbox.Text = "마늘 후레이크";
            this.grtpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grtpp_ckbox.UseVisualStyleBackColor = true;
            this.grtpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // croqtpp_ckbox
            // 
            this.croqtpp_ckbox.AutoSize = true;
            this.croqtpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.croqtpp_ckbox.Location = new System.Drawing.Point(151, 340);
            this.croqtpp_ckbox.Name = "croqtpp_ckbox";
            this.croqtpp_ckbox.Size = new System.Drawing.Size(142, 32);
            this.croqtpp_ckbox.TabIndex = 10;
            this.croqtpp_ckbox.Text = "고로케";
            this.croqtpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.croqtpp_ckbox.UseVisualStyleBackColor = true;
            this.croqtpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // eggtpp_ckbox
            // 
            this.eggtpp_ckbox.AutoSize = true;
            this.eggtpp_ckbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eggtpp_ckbox.Location = new System.Drawing.Point(3, 340);
            this.eggtpp_ckbox.Name = "eggtpp_ckbox";
            this.eggtpp_ckbox.Size = new System.Drawing.Size(142, 32);
            this.eggtpp_ckbox.TabIndex = 9;
            this.eggtpp_ckbox.Text = "날계란";
            this.eggtpp_ckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.eggtpp_ckbox.UseVisualStyleBackColor = true;
            this.eggtpp_ckbox.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // tppslct2_lbl
            // 
            this.tppslct2_lbl.AutoSize = true;
            this.tppslct2_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tppslct2_lbl.Location = new System.Drawing.Point(3, 0);
            this.tppslct2_lbl.Name = "tppslct2_lbl";
            this.tppslct2_lbl.Size = new System.Drawing.Size(446, 20);
            this.tppslct2_lbl.TabIndex = 3;
            this.tppslct2_lbl.Text = "토핑을 선택하세요";
            this.tppslct2_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tppend_btn
            // 
            this.tppend_btn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tppend_btn.Location = new System.Drawing.Point(566, 589);
            this.tppend_btn.Name = "tppend_btn";
            this.tppend_btn.Size = new System.Drawing.Size(95, 97);
            this.tppend_btn.TabIndex = 2;
            this.tppend_btn.Text = "완료";
            this.tppend_btn.UseVisualStyleBackColor = true;
            this.tppend_btn.Click += new System.EventHandler(this.button35_Click);
            // 
            // slctprice_txt
            // 
            this.slctprice_txt.BackColor = System.Drawing.SystemColors.Control;
            this.slctprice_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.slctprice_txt.ForeColor = System.Drawing.SystemColors.Control;
            this.slctprice_txt.Location = new System.Drawing.Point(3, 589);
            this.slctprice_txt.Multiline = true;
            this.slctprice_txt.Name = "slctprice_txt";
            this.slctprice_txt.Size = new System.Drawing.Size(53, 56);
            this.slctprice_txt.TabIndex = 3;
            // 
            // price_lbl
            // 
            this.price_lbl.AutoSize = true;
            this.price_lbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.price_lbl.ForeColor = System.Drawing.SystemColors.Control;
            this.price_lbl.Location = new System.Drawing.Point(566, 103);
            this.price_lbl.Name = "price_lbl";
            this.price_lbl.Size = new System.Drawing.Size(95, 12);
            this.price_lbl.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.Location = new System.Drawing.Point(102, 589);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(458, 97);
            this.dataGridView2.TabIndex = 5;
            // 
            // slct_txt
            // 
            this.slct_txt.BackColor = System.Drawing.SystemColors.Control;
            this.slct_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.slct_txt.ForeColor = System.Drawing.SystemColors.Control;
            this.slct_txt.Location = new System.Drawing.Point(3, 106);
            this.slct_txt.Name = "slct_txt";
            this.slct_txt.Size = new System.Drawing.Size(93, 14);
            this.slct_txt.TabIndex = 6;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 749);
            this.Controls.Add(this.tableLayoutPanel9);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "메인화면";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.main_panel.ResumeLayout(false);
            this.menutab.ResumeLayout(false);
            this.currypage.ResumeLayout(false);
            this.tab_Panel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.udonpage.ResumeLayout(false);
            this.tab_Panel2.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.pastapage.ResumeLayout(false);
            this.tab_Panel3.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.setpage.ResumeLayout(false);
            this.tab_Panel4.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.sidepage.ResumeLayout(false);
            this.tab_Panel5.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel36.PerformLayout();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel35.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.tableLayoutPanel34.PerformLayout();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel33.PerformLayout();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel32.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel31.PerformLayout();
            this.menu_panel.ResumeLayout(false);
            this.menu_panel.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel main_panel;
        private System.Windows.Forms.TableLayoutPanel menu_panel;
        private System.Windows.Forms.Button currybtn;
        private System.Windows.Forms.Button udonbtn;
        private System.Windows.Forms.Button pastabtn;
        private System.Windows.Forms.Button sidebtn;
        private System.Windows.Forms.Button setbtn;
        private System.Windows.Forms.TabControl menutab;
        private System.Windows.Forms.TabPage currypage;
        private System.Windows.Forms.TabPage udonpage;
        private System.Windows.Forms.TabPage pastapage;
        private System.Windows.Forms.TabPage setpage;
        private System.Windows.Forms.TabPage sidepage;
        private System.Windows.Forms.TableLayoutPanel tab_Panel1;
        private System.Windows.Forms.Button mncrry_btn;
        private System.Windows.Forms.Button frkcrry_btn;
        private System.Windows.Forms.Label sfcrry_lbl;
        private System.Windows.Forms.Label hbckcrry_lbl;
        private System.Windows.Forms.Label shrcrry_lbl;
        private System.Windows.Forms.Label bfcrry_lbl;
        private System.Windows.Forms.Label frkcrry_lbl;
        private System.Windows.Forms.Button shrcrry_btn;
        private System.Windows.Forms.Button bfcrry_btn;
        private System.Windows.Forms.Button hbckcrry_btn;
        private System.Windows.Forms.Button sfcrry_btn;
        private System.Windows.Forms.Label mncrry_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button del_btn;
        private System.Windows.Forms.Button count_btn;
        private System.Windows.Forms.TableLayoutPanel tab_Panel2;
        private System.Windows.Forms.Label hbckudon_lbl;
        private System.Windows.Forms.Label sfudon_lbl;
        private System.Windows.Forms.Label shrudon_lbl;
        private System.Windows.Forms.Label bfudon_lbl;
        private System.Windows.Forms.Label mshudon_lbl;
        private System.Windows.Forms.Button bfudon_btn;
        private System.Windows.Forms.Button mshudon_btn;
        private System.Windows.Forms.Button mnudon_btn;
        private System.Windows.Forms.Button shrudon_btn;
        private System.Windows.Forms.Button sfudon_btn;
        private System.Windows.Forms.Button hbckudon_btn;
        private System.Windows.Forms.Label mnudon_lbl;
        private System.Windows.Forms.TableLayoutPanel tab_Panel3;
        private System.Windows.Forms.Label hbckpst_lbl;
        private System.Windows.Forms.Label hbpst_lbl;
        private System.Windows.Forms.Label mshpst_lbl;
        private System.Windows.Forms.Button hbpst_btn;
        private System.Windows.Forms.Button mshpst_btn;
        private System.Windows.Forms.Button mnpst_btn;
        private System.Windows.Forms.Button hbckpst_btn;
        private System.Windows.Forms.Label mnpst_lbl;
        private System.Windows.Forms.TableLayoutPanel tab_Panel4;
        private System.Windows.Forms.Label twosetb_lbl;
        private System.Windows.Forms.Label twoseta_lbl;
        private System.Windows.Forms.Label sfset_lbl;
        private System.Windows.Forms.Label fkset_lbl;
        private System.Windows.Forms.Label ckset_lbl;
        private System.Windows.Forms.Button fkset_btn;
        private System.Windows.Forms.Button ckset_btn;
        private System.Windows.Forms.Button bfset_btn;
        private System.Windows.Forms.Button sfset_btn;
        private System.Windows.Forms.Button twoseta_btn;
        private System.Windows.Forms.Button twosetb_btn;
        private System.Windows.Forms.Label bfset_lbl;
        private System.Windows.Forms.TableLayoutPanel tab_Panel5;
        private System.Windows.Forms.Label ckgasside_lbl;
        private System.Windows.Forms.Label chdonside_lbl;
        private System.Windows.Forms.Label shrside_lbl;
        private System.Windows.Forms.Label ssgside_lbl;
        private System.Windows.Forms.Label ckside_lbl;
        private System.Windows.Forms.Button ssgside_btn;
        private System.Windows.Forms.Button ckside_btn;
        private System.Windows.Forms.Button crbside_btn;
        private System.Windows.Forms.Button shrside_btn;
        private System.Windows.Forms.Button chdonside_btn;
        private System.Windows.Forms.Button ckgasside_btn;
        private System.Windows.Forms.Label crbside_lbl;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label mncrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label fkcrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label bfcrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label shrcrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label hbckcrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label sfcrryprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        public System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label tppslct_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label spcslct_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        public System.Windows.Forms.CheckBox chcroqtpp_ckbox;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        public System.Windows.Forms.CheckBox chstpp_ckbox;
        private System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.CheckBox wlshtpp_ckbox;
        public System.Windows.Forms.CheckBox grtpp_ckbox;
        public System.Windows.Forms.CheckBox croqtpp_ckbox;
        public System.Windows.Forms.CheckBox eggtpp_ckbox;
        private System.Windows.Forms.Label tppslct2_lbl;
        private System.Windows.Forms.Button tppend_btn;
        private System.Windows.Forms.TextBox slctprice_txt;
        public System.Windows.Forms.Label price_lbl;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox slct_txt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label mnudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label mshudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label bfudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label hbckudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label sfudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label shrudonprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label mnpstprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Label mshpstprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Label hbpstprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label hbckpstprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Label fksetprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Label bfsetprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label cksetprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Label sfsetprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Label twosetbprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Label twosetaprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Label ckgassideprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Label chdonsideprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Label shrsideprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Label ssgsideprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Label cksideprc_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label crbsideprc_lbl;
        private System.Windows.Forms.Button return_btn;
    }
}

